package com.example.enroll.ui.login;

public class Admin {


    private String username;
    private String password;

    public Admin(String username, String password) {
        this.username = username;
        this.password = password;
    }

}
